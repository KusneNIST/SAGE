"""Shared methods for distance and similarity classes."""


class BaseDS:  # base distance and similarity class
    """Base Class for Distance and Similarity types."""
