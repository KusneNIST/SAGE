"""Base Class for Data Pipelines."""
from dataclasses import dataclass


@dataclass
class BaseDataPipeline:
    """Base Class for Data Pipelines."""

    pass
